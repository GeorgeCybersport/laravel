<?php $__env->startSection('content'); ?>
    <form method="POST" action="<?php echo e(route('news.update', $news->id)); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <select name="category_id">
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($category->id); ?>" <?php if($category->id == $news->category_id): ?> selected <?php endif; ?>><?php echo e($category->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select><br/>
        <input type="text" name="title" placeholder="Заголовок" value="<?php echo e($news->title); ?>"><br/>
        <textarea name="content" id="content" placeholder="Контент" cols="30" rows="10"><?php echo e($news->content); ?></textarea><br/>
        <input type="submit">
    </form>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Education\laravel-hw3\resources\views/news/edit.blade.php ENDPATH**/ ?>