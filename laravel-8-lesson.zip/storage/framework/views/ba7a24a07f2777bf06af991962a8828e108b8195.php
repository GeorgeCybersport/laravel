<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet"
          integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
    <title>Document</title>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <div class="container-fluid">
        <a class="navbar-brand" href="<?php echo e(route("start")); ?>">Main</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link <?php if(Route::is('news') or Route::is('news.*')): ?> active <?php endif; ?>" aria-current="page" href="<?php echo e(route("news")); ?>">News</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php if(Route::is('categories') or Route::is('categories.*')): ?> active <?php endif; ?>" href="<?php echo e(route("categories")); ?>">Categories</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php if(Route::is('feedback') or Route::is('feedback.*')): ?> active <?php endif; ?>" href="<?php echo e(route("feedback")); ?>">Feedback</a>
                </li>
                <?php if (\Illuminate\Support\Facades\Blade::check('admin')): ?>
                <li class="nav-item">
                    <a class="nav-link <?php if(Route::is('admin') or Route::is('admin.*')): ?> active <?php endif; ?>" href="<?php echo e(route("admin.index")); ?>">Admin</a>
                </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>
<div class="container">
    <?php if($errors->any()): ?>
        <div class="font-medium text-red-600">
            <?php echo e(__('Whoops! Something went wrong.')); ?>

        </div>

        <ul class="mt-3 list-disc list-inside text-sm text-red-600">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    <?php endif; ?>
    <?php echo $__env->yieldContent('content'); ?>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4"
        crossorigin="anonymous"></script>
</body>
</html>
<?php /**PATH E:\Education\laravel-hw3\resources\views/index.blade.php ENDPATH**/ ?>