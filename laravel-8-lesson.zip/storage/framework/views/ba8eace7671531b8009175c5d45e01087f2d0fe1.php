<?php $__env->startSection('content'); ?>
    <h1><?php echo e($news->title); ?></h1>
    <br>
    <p><?php echo e($news->content); ?></p>
    <?php if (\Illuminate\Support\Facades\Blade::check('admin')): ?><br>
    <br><a class="btn btn-primary" href="<?php echo e(route('news.edit', $news->id)); ?>">Редактировать новость</a><br><br>
    <form method="POST" action="<?php echo e(route('news.delete', $news->id)); ?>">
        <?php echo csrf_field(); ?> <?php echo method_field("delete"); ?>
        <button class="btn btn-danger">Удалить новость</button>
    </form><?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Education\laravel-hw3\resources\views/news/single.blade.php ENDPATH**/ ?>