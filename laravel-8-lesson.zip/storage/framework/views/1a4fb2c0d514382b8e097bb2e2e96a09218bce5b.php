<?php $__env->startSection('content'); ?>
    <h3>Форма обратной связи</h3>
    <form method="POST" action="<?php echo e(route('categories.store')); ?>">
        <?php echo csrf_field(); ?>
        <input type="text" name="name" placeholder="Имя"><br><br>
        <input type="text" name="email" placeholder="Email"><br><br>
        <textarea name="message" placeholder="Текст сообщения"></textarea>
        <input type="submit">
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Education\laravel-hw3\resources\views/feedback/index.blade.php ENDPATH**/ ?>