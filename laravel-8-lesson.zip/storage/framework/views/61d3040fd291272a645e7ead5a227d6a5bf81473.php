<?php $__env->startSection('content'); ?>
    <h3>Редактирование пользователя - #<?php echo e($user->id); ?></h3>
    <form method="POST" action="<?php echo e(route('admin.users.update', $user->id)); ?>">
        <div class="form-group">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
        <label for="name">Никнейм</label>
        <input class="form-control" id="name" type="text" name="name" value="<?php echo e($user->name); ?>"><br>
        <label for="email">Email</label>
        <input class="form-control" id="email" type="email" name="email" value="<?php echo e($user->email); ?>"><br>
        <label for="admin">Роль</label>
        <select class="form-select form-select-lg mb-3" id="admin" name="admin">
            <option value="0" <?php if($user->admin): ?> selected <?php endif; ?>>Пользователь</option>
            <option value="1" <?php if($user->admin): ?> selected <?php endif; ?>>Администратор</option>
        </select>
            <br>
            <button class="btn btn-primary">Редактировать</button>
    </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Education\laravel-hw3\resources\views/admin/users/edit.blade.php ENDPATH**/ ?>