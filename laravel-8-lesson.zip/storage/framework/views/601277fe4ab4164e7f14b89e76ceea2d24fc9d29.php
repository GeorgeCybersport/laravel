<?php $__env->startSection('content'); ?>
    <h3>Категории</h3>
    <ul class="list-group">
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="list-group-item"><a href="<?php echo e(route("categories.single", $category->id)); ?>"><?php echo e($category->name); ?></a></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <br>
    <?php if (\Illuminate\Support\Facades\Blade::check('admin')): ?><a class="btn btn-primary" href="<?php echo e(route('categories.create')); ?>">Добавить категорию</a><?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Education\laravel-hw3\resources\views/categories/index.blade.php ENDPATH**/ ?>