<?php $__env->startSection('content'); ?>
        <h3>Новости</h3>
        <ul class="list-group">
            <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $new): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="list-group-item"><a href="<?php echo e(route("news.single", $new->id)); ?>"><?php echo e($new->title); ?></a></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    <br>
    <?php if (\Illuminate\Support\Facades\Blade::check('admin')): ?><a class="btn btn-primary" href="<?php echo e(route('news.create')); ?>">Добавить новость</a><?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Education\laravel-hw3\resources\views/news/index.blade.php ENDPATH**/ ?>