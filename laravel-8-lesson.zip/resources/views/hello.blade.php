@extends('index');
@section('content')
    <h1>Всем привет</h1>
@endsection
